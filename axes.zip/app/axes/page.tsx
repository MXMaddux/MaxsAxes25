import React from "react";
import { guitar_list } from "@/guitars_list"; // Update import path
import Image from "next/image";
import Link from "next/link";

interface Guitar {
  id: string;
  image: string;
  model: string;
  // Add other guitar properties if needed
}

const AxesPage: React.FC = () => {
  return (
    <section className="min-h-[60vh] h-[calc(100vh-13px)] grid place-items-center bg-blue-700 w-full py-20">
      <div className="w-[90vw] max-w-[1170px] mx-auto">
        <div className="grid grid-cols-2 gap-1 mb-2 md:grid-cols-3 md:gap-2 md:w-full md:mx-2 lg:grid-cols-3 lg:gap-4">
          {guitar_list.map((guitar: Guitar) => {
            const { id, image, model } = guitar;
            return (
              <div
                key={id}
                className="group relative w-full mb-4 mt-2 ml-0 md:ml-20 hover:-translate-y-1 transition-transform duration-200"
              >
                <div className="relative w-full aspect-square overflow-hidden rounded-lg shadow-lg shadow-gray-950">
                  <Image
                    src={image}
                    alt={model}
                    fill
                    className="object-cover brightness-100 group-hover:brightness-75 transition-all duration-500"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-opacity duration-500 flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <Link href={`/${id}`}>
                      <h2 className="text-blue-100 text-xl md:text-2xl absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                        Info
                      </h2>
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default AxesPage;
