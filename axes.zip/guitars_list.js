export const guitar_list = [
    {
        id: "-NaDEWffR2P_fegvjEHc",
        brand: "Maddux",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla auctor ex vel erat pretium blandit quis vel elit. Sed hendrerit porta odio, id fringilla magna fermentum eget. Quisque commodo mauris varius lorem tincidunt, lacinia aliquam ligula dictum. Maecenas cursus tellus sed tincidunt tempus. Suspendisse laoreet vel libero sit amet ornare. Suspendisse potenti. Vestibulum sapien elit, dapibus ut gravida vitae, molestie dictum dui. Morbi sed nisl non erat convallis placerat convallis quis ligula.",
        image: "https://i.ibb.co/QQHsj0J/IMG-4297.jpg",
        model: "S-style Partscaster",
        price: 899999,
        stock: 1
    },
    {
        id: "-NaDP8qXTtWYvcc7Iria",
        brand: "Maddux",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla auctor ex vel erat pretium blandit quis vel elit. Sed hendrerit porta odio, id fringilla magna fermentum eget. Quisque commodo mauris varius lorem tincidunt, lacinia aliquam ligula dictum. Maecenas cursus tellus sed tincidunt tempus. Suspendisse laoreet vel libero sit amet ornare. Suspendisse potenti. Vestibulum sapien elit, dapibus ut gravida vitae, molestie dictum dui. Morbi sed nisl non erat convallis placerat convallis quis ligula.",
    image: "https://i.ibb.co/7kWzyhT/IMG-4575.jpg",
    model: "S-style Partscaster",
    price: 799999,
    stock: 1
    },
    {
        id: "-NaDPWUF7p3S9Djr-Ul7",
        brand: "Maddux",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla auctor ex vel erat pretium blandit quis vel elit. Sed hendrerit porta odio, id fringilla magna fermentum eget. Quisque commodo mauris varius lorem tincidunt, lacinia aliquam ligula dictum. Maecenas cursus tellus sed tincidunt tempus. Suspendisse laoreet vel libero sit amet ornare. Suspendisse potenti. Vestibulum sapien elit, dapibus ut gravida vitae, molestie dictum dui. Morbi sed nisl non erat convallis placerat convallis quis ligula.",
    image: "https://i.ibb.co/8bLZT5p/IMG-4599.jpg",
    model: "S-style Partscaster",
    price: 699999,
    stock: 1
    },
    {
        id: "-NaDQ-v4VtAU-lsSy01G",
        brand: "Kissel",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla auctor ex vel erat pretium blandit quis vel elit. Sed hendrerit porta odio, id fringilla magna fermentum eget. Quisque commodo mauris varius lorem tincidunt, lacinia aliquam ligula dictum. Maecenas cursus tellus sed tincidunt tempus. Suspendisse laoreet vel libero sit amet ornare. Suspendisse potenti. Vestibulum sapien elit, dapibus ut gravida vitae, molestie dictum dui. Morbi sed nisl non erat convallis placerat convallis quis ligula.",
    image: "https://i.ibb.co/yNFT73q/IMG-6018.jpg",
    model: "Headless Hoarseman",
    price: 799999,
    stock: 1
    },
]